﻿using System;
using System.Windows;
using System.IO;
using System.Threading;

namespace lab5._2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        class Logger
        {
            private readonly string _filePath;
            private Semaphore _semaphore;
            private Mutex _mutex; // Добавляем Mutex для синхронизации доступа к файлу

            public Logger(string filePath)
            {
                _filePath = filePath;
                _semaphore = new Semaphore(5, 5);  // Ограничиваем до 5 потоков одновременно
                _mutex = new Mutex();  // Создаем Mutex для синхронизации работы с файлом
                File.WriteAllText(_filePath, string.Empty);  // Очищаем файл при запуске
            }

            public void WriteLog(string logMessage)
            {
                _semaphore.WaitOne();  // Блокируем доступ к файлу для других потоков

                _mutex.WaitOne();  // Блокируем доступ к файлу для других потоков на уровне записи
                try
                {
                    File.AppendAllText(_filePath, logMessage + Environment.NewLine);
                }
                finally
                {
                    _mutex.ReleaseMutex();  // Разблокируем доступ к файлу
                    _semaphore.Release();   // Разблокируем семафор
                }
            }
        }

        private void StartThreads_Click(object sender, RoutedEventArgs e)
        {
            int threadCount = int.Parse(ThreadCountTextBox.Text);
            Logger logger = new Logger("log.txt");

            for (int i = 0; i < threadCount; i++)
            {
                int threadNum = i;
                new Thread(() =>
                {
                    Random random = new Random();
                    int delay = random.Next(800, 1200); // Задержка ~1 секунда
                    Thread.Sleep(delay);
                    string logMessage = $"Thread {threadNum}: {DateTime.Now:HH:mm:ss.fff}, Delay: {delay} ms";
                    logger.WriteLog(logMessage);  // Запись сообщения в файл

                    // Используем Dispatcher, чтобы добавить сообщение в UI
                    Dispatcher.Invoke(() => LogTextBox.AppendText(logMessage + "\n"));
                }).Start();
            }
        }
    }
}
